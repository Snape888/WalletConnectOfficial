import { writable } from "svelte/store";

export const transactionRegister = writable({});
export const pending = writable([]);