import { writable } from "svelte/store";

export const stethBalance = writable("n/a");
export const daiAllowance = writable("n/a");

export const infoTwo = writable("n/a");
export const stethAllowance = writable("n/a");
export const toggle = writable("false");
export const first = writable("n/a");
export const second = writable("n/a");
export const third = writable("n/a");