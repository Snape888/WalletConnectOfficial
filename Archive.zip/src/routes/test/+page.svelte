<script>
import {
	getAccount,
	getChainId,
	reconnect,
	watchAccount,
	watchChainId,
} from '@wagmi/core'

</script>
{watchAccount}



<w3m-button />