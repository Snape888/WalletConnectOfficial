<script>
    import { page } from '$app/stores';
    import ConvertPage from '../+page.svelte'
</script>

<ConvertPage />