<script>
    import { page } from '$app/stores';
    import DashboardPage from '../Dashboard/+page.svelte'
</script>

<DashboardPage />