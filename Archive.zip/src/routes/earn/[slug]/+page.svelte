<script>
    import { page } from '$app/stores';
    import EarnPage from '../+page.svelte'
</script>

<EarnPage />