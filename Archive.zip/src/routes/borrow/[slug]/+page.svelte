<script>
    import { page } from '$app/stores';
    import BorrowPage from '../+page.svelte'
</script>

<BorrowPage />