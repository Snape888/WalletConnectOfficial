<script>
    import { page } from '$app/stores';
    import DocsPage from '../+page.svelte'
</script>

<DocsPage />