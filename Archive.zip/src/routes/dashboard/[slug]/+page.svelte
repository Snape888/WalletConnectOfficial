<script>
    import { page } from '$app/stores';
    import DashboardPage from '../+page.svelte'
</script>

<DashboardPage />